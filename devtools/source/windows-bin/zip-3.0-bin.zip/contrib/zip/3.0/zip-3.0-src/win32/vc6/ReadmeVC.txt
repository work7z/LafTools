VC6 Readme

This directory has a VC6 project list that can be used to compile Zip
and the utilities.  It does not include bzip2 support.

The vc6bz2 directory provides a variant of this directory that includes
the settings needed for including bzip2 support in Zip.

Ed Gordon
26 March 2007
